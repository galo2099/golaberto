import hashlib,json,os,pathlib,resource,subprocess,time
root=pathlib.Path('/private/tmp/flamengo-tree-experiment')
binary=root/'target/release/examples/branch_stratification'
request=pathlib.Path('/Users/robsonaraujo/work/golaberto/experiments/rare_positions/reference/2026-09-30-hundredfold/inputs/group-16498-44eabb47.json')
base={k:v for k,v in os.environ.items() if not k.startswith(('TREE_','RUST_ODDS_','RARE_POSITION_'))}
rows=[]
for name,training,leaves,values in [('static32',0,32,4000000),('trained32',200,32,4000000),('static64',0,64,4000000)]:
 env=dict(base,TREE_MODE='1',TREE_TRAINING=str(training),TREE_LEAVES=str(leaves),TREE_GUIDE_VALUES=str(values))
 cmd=[str(binary),str(request),'17','13','25000','808','trained','adaptive','4','tilt','plain','200','200']
 before=resource.getrusage(resource.RUSAGE_CHILDREN);start=time.perf_counter()
 p=subprocess.run(cmd,env=env,capture_output=True,text=True)
 after=resource.getrusage(resource.RUSAGE_CHILDREN)
 (root/(name+'.jsonl')).write_text(p.stdout);(root/(name+'.log')).write_text(p.stderr)
 events=[json.loads(s) for s in p.stdout.splitlines() if s.startswith('{')]
 row={'name':name,'command':cmd,'flags':{k:v for k,v in env.items() if k.startswith('TREE_')},'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'request_sha256':hashlib.sha256(request.read_bytes()).hexdigest(),'wall_ms':(time.perf_counter()-start)*1000,'cpu_ms':1000*(after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime),'status':p.returncode,'events':events}
 rows.append(row)
 print(json.dumps({k:row[k] for k in ['name','wall_ms','cpu_ms','status']}),flush=True)
 if events:
  print(json.dumps({'tree':{k:v for k,v in events[0]['proposal'].get('tree',{}).items() if k!='selected'},'result':{k:events[-1].get(k) for k in ['accepted','main','check','elapsed_ms']}}),flush=True)
(root/'screen-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
