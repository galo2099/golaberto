"""Reconstruct the pre-cache v1 implementation from the read-only v2 source."""

from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import tarfile


REPOSITORY = Path("/Users/robsonaraujo/work/golaberto")
ARTIFACT = REPOSITORY / "experiments/rare_positions/2026-10-02-lazy-three"
V2_ROOT = Path("/private/tmp/golaberto-r45/v2-source")
SOURCE = V2_ROOT / "odds-rust/src"
DESTINATION = Path("/private/tmp/golaberto-r45/v1-source/odds-rust/src")
BASE_REVISION = "ac92a8ab88656c2e20a24b37c1f3c3d3dcfdb4cd"
SUPPORT_PATHS = (
    "odds-rust/Cargo.toml",
    "odds-rust/Cargo.lock",
    "odds-rust/examples",
    "odds-rust/tests",
    "odds-rust/third_party",
    "stats/core",
)


def archive_paths(destination: Path, paths: tuple[str, ...]) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    archive = destination / ".baseline-support.tar"
    with archive.open("wb") as stream:
        subprocess.run(
            ["git", "-C", str(REPOSITORY), "archive", BASE_REVISION, *paths],
            stdout=stream,
            check=True,
        )
    with tarfile.open(archive) as bundle:
        bundle.extractall(destination)
    archive.unlink()


def prepare_frozen_v2() -> None:
    if V2_ROOT.exists():
        shutil.rmtree(V2_ROOT)
    V2_ROOT.mkdir(parents=True)
    archive_paths(V2_ROOT, ("odds-rust/src", *SUPPORT_PATHS))
    subprocess.run(
        [
            "patch",
            "--batch",
            "-p1",
            "-d",
            str(V2_ROOT),
            "-i",
            str(ARTIFACT / "prototype-v2.patch"),
        ],
        check=True,
    )
    expected = json.loads((ARTIFACT / "source-hashes.json").read_text())["v2"]
    for relative, expected_hash in expected.items():
        digest = hashlib.sha256(
            (V2_ROOT / Path(relative)).read_bytes()
        ).hexdigest()
        if digest != expected_hash:
            raise RuntimeError(f"frozen v2 hash mismatch for {relative}: {digest}")


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one match, found {count}")
    return text.replace(old, new, 1)


def remove_test(text: str, test_name: str) -> str:
    pattern = re.compile(
        r"    #\[test\]\n    fn "
        + re.escape(test_name)
        + r"\(\) \{.*?\n    \}\n(?=    #\[test\])",
        re.DOTALL,
    )
    text, count = pattern.subn("", text, count=1)
    if count != 1:
        raise RuntimeError(f"could not remove expected v2-only test {test_name}")
    return text


def reconstruct_lazy() -> None:
    path = DESTINATION / "joint_caps/propagated/lazy.rs"
    text = path.read_text()
    text = replace_once(
        text,
        "    pair_cache: HashMap<(usize, [usize; 2]), Arc<super::PairGuide>>,\n"
        "    pair_setup_work: usize,\n",
        "",
        "pair cache fields",
    )
    text = replace_once(
        text,
        "            pair_cache: HashMap::new(),\n            pair_setup_work: 0,\n",
        "",
        "pair cache initialization",
    )
    cached_pair = re.compile(
        r'        let pair = if self\.experiment == "pair" \{\n'
        r"            self\.pair_setup_work \+= 64 \* guide\.games\.len\(\);\n"
        r"            super::PairGuide::choose\(&guide, &base, self\.cell\)\.map\(\|teams\| \{\n"
        r"                let key = \(Arc::as_ptr\(&guide\) as usize, teams\);\n"
        r"                if let Some\(p\) = self\.pair_cache\.get\(&key\) \{\n"
        r"                    p\.clone\(\)\n"
        r"                \} else \{\n"
        r"                    let \(pair, values\) = super::PairGuide::for_pair\(&guide, teams\);\n"
        r"                    self\.guide_values \+= values;\n"
        r"                    let pair = Arc::new\(pair\);\n"
        r"                    self\.pair_cache\.insert\(key, pair\.clone\(\)\);\n"
        r"                    pair\n"
        r"                \}\n"
        r"            \}\)\n"
        r"        \} else \{\n"
        r"            None\n"
        r"        \};"
    )
    text, count = cached_pair.subn(
        "        let pair = if self.experiment == \"pair\" {\n"
        "            super::PairGuide::new(&guide, &base, self.cell).map(|(pair, values)| {\n"
        "                self.guide_values += values;\n"
        "                Arc::new(pair)\n"
        "            })\n"
        "        } else {\n"
        "            None\n"
        "        };",
        text,
        count=1,
    )
    if count != 1:
        raise RuntimeError("formatted cached PairGuide construction did not match")
    text = replace_once(
        text,
        "        crate::rare_tail::budget::setup_cost(self.nodes, self.guide_values) + self.pair_setup_work",
        "        crate::rare_tail::budget::setup_cost(self.nodes, self.guide_values)",
        "pair setup work accounting",
    )
    text = replace_once(
        text,
        '"pair_cached_tables":self.pair_cache.len(),"pair_selection_work":self.pair_setup_work,',
        "",
        "pair cache diagnostics",
    )
    text = remove_test(text, "pair_tables_reuse_the_same_residual_guide_without_new_allocation")
    path.write_text(text)


def reconstruct_pair() -> None:
    path = DESTINATION / "joint_caps/propagated/pair.rs"
    text = path.read_text()
    text = replace_once(
        text,
        "    #[cfg(test)]\n"
        "    pub(super) fn new(guide: &Guide, base: &[i32], cell: Cell) -> Option<(Self, usize)> {\n"
        "        Some(Self::for_pair(guide, Self::choose(guide, base, cell)?))\n"
        "    }\n"
        "    pub(super) fn choose(guide: &Guide, base: &[i32], cell: Cell) -> Option<[usize; 2]> {",
        "    pub(super) fn new(guide: &Guide, base: &[i32], cell: Cell) -> Option<(Self, usize)> {",
        "restore allocating PairGuide::new",
    )
    text = replace_once(
        text,
        "        Some(teams)\n    }\n    pub(super) fn for_pair(guide: &Guide, teams: [usize; 2]) -> (Self, usize) {",
        "        Some(Self::for_pair(guide, teams))\n    }\n    fn for_pair(guide: &Guide, teams: [usize; 2]) -> (Self, usize) {",
        "allocate selected pair guide",
    )
    text = remove_test(
        text,
        "pair_kernel_is_unchanged_by_disjoint_fixtures_and_invalidates_on_pair_results",
    )
    path.write_text(text)


def reconstruct_propagated() -> None:
    path = DESTINATION / "joint_caps/propagated.rs"
    text = path.read_text()
    text = replace_once(text, "        let mut pair_kernel = None;\n", "", "pair kernel cache state")
    cached_kernel = re.compile(
        r"                    let kernel = \*pair_kernel\.get_or_insert_with\(\|\| \{\n"
        r"                        pair\.kernel\(\n"
        r"                            step \+ 1,\n"
        r"                            points,\n"
        r"                            target,\n"
        r"                            count_below,\n"
        r"                            &mut operations\.guidance,\n"
        r"                        \)\n"
        r"                    \}\);"
    )
    text, count = cached_kernel.subn(
        "                    let kernel = pair.kernel(\n"
        "                        step + 1,\n"
        "                        points,\n"
        "                        target,\n"
        "                        count_below,\n"
        "                        &mut operations.guidance,\n"
        "                    );",
        text,
        count=1,
    )
    if count != 1:
        raise RuntimeError("formatted pair kernel cache block did not match")
    invalidate = re.compile(
        r"            if self\n"
        r"                \.pair\n"
        r"                \.as_ref\(\)\n"
        r"                \.is_some_and\(\|p\| p\.teams\.contains\(&g\.home\) \|\| p\.teams\.contains\(&g\.away\)\)\n"
        r"            \{\n"
        r"                pair_kernel = None;\n"
        r"            \}\n"
    )
    text, count = invalidate.subn("", text, count=1)
    if count != 1:
        raise RuntimeError("pair kernel cache invalidation block did not match")
    path.write_text(text)


def validate() -> None:
    lazy = (DESTINATION / "joint_caps/propagated/lazy.rs").read_text()
    pair = (DESTINATION / "joint_caps/propagated/pair.rs").read_text()
    propagated = (DESTINATION / "joint_caps/propagated.rs").read_text()
    for stale in ("pair_cache", "pair_setup_work", "pair_cached_tables", "pair_selection_work"):
        if stale in lazy:
            raise RuntimeError(f"v1 lazy implementation still contains {stale}")
    if "pub(super) fn new(guide: &Guide, base: &[i32], cell: Cell) -> Option<(Self, usize)>" not in pair:
        raise RuntimeError("PairGuide::new does not select and allocate the pair table")
    if "let mut pair_kernel" in propagated or "get_or_insert_with" in propagated:
        raise RuntimeError("v1 fixture loop still caches pair kernels")
    if "fn all_three_experiments_match_exhaustive_ranks_and_keep_defensive_support" not in lazy:
        raise RuntimeError("all-three-modes regression test was not preserved")
    if "fn marginal_density_identity_includes_alternate_overlap_and_null_outcomes" not in lazy:
        raise RuntimeError("marginal density regression test was not preserved")
    if "fn correlated_kernel_matches_enumerated_shared_and_external_results" not in pair:
        raise RuntimeError("exact correlated kernel test was not preserved")
    if "pair_tables_reuse_the_same_residual_guide_without_new_allocation" in lazy:
        raise RuntimeError("cache-specific lazy test remains in v1")
    if "pair_kernel_is_unchanged_by_disjoint_fixtures_and_invalidates_on_pair_results" in pair:
        raise RuntimeError("cache-specific kernel test remains in v1")


if __name__ == "__main__":
    prepare_frozen_v2()
    archive_paths(Path("/private/tmp/golaberto-r45/v1-source"), SUPPORT_PATHS)
    if DESTINATION.exists():
        shutil.rmtree(DESTINATION)
    shutil.copytree(SOURCE, DESTINATION)
    reconstruct_lazy()
    reconstruct_pair()
    reconstruct_propagated()
    validate()
    print(f"reconstructed and validated {DESTINATION}")
