//! Training-only escalation of a necessary rank event. Small selected subsets
//! share internal fixtures; their marginal probabilities are never multiplied
//! as if those shared fixtures were independent.
use super::*;

fn table(
    games: Vec<RankGame>,
    t: usize,
    base: i32,
    target: i32,
    above: bool,
    padding: i32,
) -> TerminalTable {
    let span: i32 = padding
        + games
            .iter()
            .map(|g| {
                *if g.home == t { &g.hg } else { &g.ag }
                    .iter()
                    .max()
                    .unwrap()
            })
            .sum::<i32>();
    TerminalTable::new(
        games,
        t,
        (0..=span)
            .map(|a| {
                if if above {
                    base + a <= target
                } else {
                    base + a >= target
                } {
                    1.
                } else {
                    0.
                }
            })
            .collect(),
    )
}

/// Exact probability of at most `allowed` strict exceptions in `selected`,
/// conditional on a fixed target path. Ties are retained in the necessary event.
fn screen(
    games: &[RankGame],
    points: &[i32],
    target: i32,
    selected: &[usize],
    above: bool,
    allowed: usize,
) -> Option<(f64, usize)> {
    let internal: Vec<_> = games
        .iter()
        .copied()
        .filter(|g| selected.contains(&g.home) && selected.contains(&g.away))
        .collect();
    let states = 3usize.checked_pow(internal.len() as u32)?;
    if states > 12000 {
        return None;
    }
    let tables: Vec<_> = selected
        .iter()
        .map(|&t| {
            table(
                games
                    .iter()
                    .copied()
                    .filter(|g| {
                        (g.home == t || g.away == t) && !internal.iter().any(|v| v.index == g.index)
                    })
                    .collect(),
                t,
                points[t],
                target,
                above,
                internal
                    .iter()
                    .filter(|g| g.home == t || g.away == t)
                    .map(|g| {
                        *if g.home == t { &g.hg } else { &g.ag }
                            .iter()
                            .max()
                            .unwrap()
                    })
                    .sum(),
            )
        })
        .collect();
    let mut mass = 0.;
    for mut code in 0..states {
        let mut added = vec![0; selected.len()];
        let mut weight = 1.;
        for g in &internal {
            let o = code % 3;
            code /= 3;
            weight *= g.prob[o];
            added[selected.iter().position(|&t| t == g.home).unwrap()] += g.hg[o];
            added[selected.iter().position(|&t| t == g.away).unwrap()] += g.ag[o];
        }
        let mut dp = vec![0.; allowed + 1];
        dp[0] = 1.;
        for (tab, gain) in tables.iter().zip(added) {
            let safe = tab.mass(gain as usize).clamp(0., 1.);
            for k in (0..=allowed).rev() {
                dp[k] = dp[k] * safe + if k > 0 { dp[k - 1] * (1. - safe) } else { 0. };
            }
        }
        mass += weight * dp.iter().sum::<f64>();
    }
    Some((mass, states))
}

impl LazyJoint {
    fn residual_cases(&mut self, m: &Model, width: usize) -> serde_json::Value {
        self.cases.clear();
        self.node_limit = self.nodes + 20000;
        let old = self.subset;
        self.subset = false;
        let keys: Vec<_> = self
            .mixture
            .iter()
            .map(|(k, _)| k.clone())
            .take(2)
            .collect();
        let mut diagnostics = Vec::new();
        for key in keys {
            let mut points = self.base.clone();
            for (g, &o) in self.target.games.iter().zip(&key) {
                points[g.home] += g.hg[o as usize];
                points[g.away] += g.ag[o as usize];
            }
            let target = points[self.cell.team];
            let rivals: Vec<_> = (0..m.n).filter(|&t| t != self.cell.team).collect();
            let d = Domains::propagate(&self.remaining, &points, &rivals, self.cell.rank, target);
            if !d.feasible {
                continue;
            }
            let fixed_above = rivals
                .iter()
                .filter(|&&t| points[t] + d.min[0][t] > target)
                .count();
            let fixed_below = rivals
                .iter()
                .filter(|&&t| points[t] + d.max[0][t] < target)
                .count();
            let above = self.cell.rank.saturating_sub(fixed_above)
                <= (m.n - 1 - self.cell.rank).saturating_sub(fixed_below);
            let allowed = if above {
                self.cell.rank - fixed_above
            } else {
                m.n - 1 - self.cell.rank - fixed_below
            };
            let mut candidates: Vec<_> = rivals
                .iter()
                .copied()
                .filter(|&t| points[t] + d.min[0][t] <= target && points[t] + d.max[0][t] >= target)
                .map(|t| {
                    let p = table(
                        self.remaining
                            .iter()
                            .copied()
                            .filter(|g| g.home == t || g.away == t)
                            .collect(),
                        t,
                        points[t],
                        target,
                        above,
                        0,
                    )
                    .mass(0);
                    (t, p)
                })
                .collect();
            candidates.sort_by(|a, b| a.1.total_cmp(&b.1).then(a.0.cmp(&b.0)));
            let selected: Vec<_> = candidates.iter().take(width).map(|&(t, _)| t).collect();
            if selected.len() <= allowed || selected.len() > 31 {
                continue;
            }
            let mut screened: Vec<_> = selected.iter().copied().take(6).collect();
            let measured = loop {
                if screened.len() <= allowed {
                    break None;
                }
                if let Some(v) = screen(&self.remaining, &points, target, &screened, above, allowed)
                {
                    break Some(v);
                }
                screened.pop();
            };
            let Some((bound, states)) = measured else {
                continue;
            };
            // This is a P-event screen, not a bound on the guided proposal's
            // hit rate. Escalation also requires independently weak pilot ESS.
            if bound * 30000. >= 1. {
                continue;
            }
            let selected_mask = selected.iter().fold(0u32, |s, &t| s | (1 << t));
            let mut cases = Cases {
                above,
                selected: selected_mask,
                patterns: Vec::new(),
                mass: 0.,
                complete: true,
            };
            fn enumerate(ts: &[usize], i: usize, left: usize, mask: u32, out: &mut Vec<u32>) {
                if out.len() >= 33 {
                    return;
                }
                if i == ts.len() {
                    out.push(mask);
                    return;
                }
                enumerate(ts, i + 1, left, mask, out);
                if left > 0 {
                    enumerate(ts, i + 1, left - 1, mask | (1 << ts[i]), out);
                }
            }
            let mut masks = Vec::new();
            enumerate(&selected, 0, allowed, 0, &mut masks);
            if masks.len() > 32 {
                cases.complete = false;
                masks.truncate(32);
            }
            masks.sort_unstable();
            for mask in masks {
                match self.build(&key, m.n, None, Some((above, mask, selected_mask))) {
                    Ok(Some(mut p)) => {
                        p.bound_guidance =
                            crate::rare_tail::value("RUST_ODDS_RARE_TAIL_RESIDUAL_BOUND_GUIDE")
                                == "1";
                        let score = p.mass * p.joint.residual_hint.max(1e-80);
                        cases.mass += score;
                        cases.patterns.push((mask, p, cases.mass));
                    }
                    Ok(None) => {}
                    Err(()) => cases.complete = false,
                }
            }
            diagnostics.push(json!({"teams":selected.iter().map(|&t|m.ids[t]).collect::<Vec<_>>(),"strict_direction":if above{"above"}else{"below"},"allowed_exceptions":allowed,"conditional_necessary_bound":bound,"screen_states":states,"screened_teams":screened.iter().map(|&t|m.ids[t]).collect::<Vec<_>>(),"cases":cases.patterns.len(),"complete":cases.complete}));
            if !cases.patterns.is_empty() && cases.mass > 0. {
                self.cases.insert(key, cases);
            }
        }
        self.subset = old;
        json!(diagnostics)
    }

    /// Keep the best independently trained depth; final estimation must use
    /// new streams. The defensive native proposal retains full event support.
    pub(crate) fn train_residual_loop(
        &mut self,
        m: &Model,
        seed: i64,
        deadline: Option<std::time::Instant>,
    ) -> (Result, serde_json::Value, u64) {
        // Cache entries depend on how many teams are conditioned. Existing
        // patterns keep their Arcs and densities; new cases use the wider block.
        let limit = crate::rare_tail::value("RUST_ODDS_RARE_TAIL_RESIDUAL_RIVALS")
            .parse::<usize>()
            .unwrap_or(4)
            .clamp(1, 6);
        if self.rival_limit != limit {
            self.rival_limit = limit;
            self.joint_cache.clear();
        }
        let mut best = Result::default();
        let mut best_cases = HashMap::new();
        let mut trace = Vec::new();
        let mut work = 0;
        for width in [3, 4, 5, 6, 8, 12, 20] {
            if deadline.is_some_and(|d| std::time::Instant::now() >= d) {
                break;
            }
            let start = std::time::Instant::now();
            let screen = self.residual_cases(m, width);
            if self.cases.is_empty() {
                trace.push(json!({"width":width,"screen":screen,"sampling_skipped":true}));
                continue;
            }
            let adaptive =
                crate::rare_tail::value("RUST_ODDS_RARE_TAIL_RESIDUAL_BOUND_GUIDE") == "adaptive";
            let setup_ms = start.elapsed().as_secs_f64() * 1000.;
            let pilot_clock = std::time::Instant::now();
            let mut pilot = self.sample(m, 2000, derive(seed, &format!("residual-pilot-{width}")));
            work += pilot.work;
            let rank_ess = pilot.ess;
            let mut bound_ess = None;
            let mut use_bounds = false;
            if adaptive && deadline.is_none_or(|d| std::time::Instant::now() < d) {
                for c in self.cases.values_mut() {
                    for (_, p, _) in &mut c.patterns {
                        p.bound_guidance = true;
                    }
                }
                let bound = self.sample(
                    m,
                    2000,
                    derive(seed, &format!("residual-bound-pilot-{width}")),
                );
                work += bound.work;
                bound_ess = Some(bound.ess);
                use_bounds = bound.ess > pilot.ess;
                if use_bounds {
                    pilot = bound;
                } else {
                    for c in self.cases.values_mut() {
                        for (_, p, _) in &mut c.patterns {
                            p.bound_guidance = false;
                        }
                    }
                }
            }
            trace.push(json!({"width":width,"screen":screen,"hits":pilot.hits,"ess":pilot.ess,"rank_ess":rank_ess,"bound_ess":bound_ess,"selected_bound_guidance":use_bounds,"probability":pilot.probability,"setup_ms":setup_ms,"pilot_ms":pilot_clock.elapsed().as_secs_f64()*1000.,"elapsed_ms":start.elapsed().as_secs_f64()*1000.}));
            let useful = pilot.ess >= 12. && pilot.hits >= 30;
            if pilot.ess > best.ess {
                best = pilot;
                best_cases = self.cases.clone();
            }
            if useful {
                break;
            }
        }
        self.cases = best_cases;
        (best, json!(trace), work)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn bounds_guidance_matches_exhaustive_single_team_intervals() {
        let games = vec![
            RankGame {
                index: 0,
                home: 0,
                away: 1,
                prob: [0.25, 0.3, 0.45],
                hg: [0, 1, 3],
                ag: [3, 1, 0],
            },
            RankGame {
                index: 1,
                home: 0,
                away: 2,
                prob: [0.2, 0.4, 0.4],
                hg: [0, 1, 3],
                ag: [3, 1, 0],
            },
        ];
        let guide = Guide::new(games.clone(), 3);
        for lo in -1..=7 {
            for hi in lo..=7 {
                let mut exact = 0.;
                for a in 0..3 {
                    for b in 0..3 {
                        let total = games[0].hg[a] + games[1].hg[b];
                        if total >= lo && total <= hi {
                            exact += games[0].prob[a] * games[1].prob[b];
                        }
                    }
                }
                assert!((guide.bounds(0, 0, lo, hi) - exact).abs() < 1e-12);
            }
        }
    }
    #[test]
    fn cardinality_screen_respects_shared_fixture_dependence() {
        let games = vec![
            RankGame {
                index: 0,
                home: 0,
                away: 1,
                prob: [0.25, 0.3, 0.45],
                hg: [0, 1, 3],
                ag: [3, 1, 0],
            },
            RankGame {
                index: 1,
                home: 0,
                away: 2,
                prob: [0.2, 0.4, 0.4],
                hg: [0, 1, 3],
                ag: [3, 1, 0],
            },
        ];
        for above in [true, false] {
            for allowed in 0..=2 {
                let mut exact = 0.;
                for a in 0..3 {
                    for b in 0..3 {
                        let totals = [games[0].hg[a] + games[1].hg[b], games[0].ag[a]];
                        let count = totals
                            .iter()
                            .filter(|&&p| if above { p > 2 } else { p < 2 })
                            .count();
                        if count <= allowed {
                            exact += games[0].prob[a] * games[1].prob[b];
                        }
                    }
                }
                let (bound, _) = screen(&games, &[0, 0, 0], 2, &[0, 1], above, allowed).unwrap();
                assert!((bound - exact).abs() < 1e-12, "{bound} vs {exact}");
            }
        }
    }
}
