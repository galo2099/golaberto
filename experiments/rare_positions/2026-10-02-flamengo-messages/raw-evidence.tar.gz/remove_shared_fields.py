from pathlib import Path
import re
root=Path('/private/tmp/flamengo-tree-experiment/source/odds-rust')
(root/'src/joint_caps/propagated.rs').write_text(Path('/private/tmp/flamengo-sampler-experiment/propagated.before.rs').read_text())
p=root/'src/joint_caps/propagated/lazy.rs';s=p.read_text();s=re.sub(r'\s*interval_power: 1\.,\n', '\n',s);s=re.sub(r'\s*nominal: None,\n','\n',s);p.write_text(s)
p=root/'src/joint_caps/propagated/lazy/strata.rs';s=p.read_text().replace('HashMap<usize, Pattern>','HashMap<usize, messages::TiltedPattern>')
s=s.replace('self.retuned.get(&index).unwrap_or(&self.strata[index].pattern)','self.retuned.get(&index).map(|q|&q.pattern).unwrap_or(&self.strata[index].pattern)')
s=s.replace('usize::from(p.nominal.is_some())','usize::from(self.retuned.contains_key(&index))')
s=re.sub(r'\n        pattern.interval_power = .*?\.unwrap_or\(1\.\);','',s,flags=re.S)
needle='''            if weight > 0. {
                r.operations.rank(m);'''
s=s.replace(needle,'''            if weight > 0. {
                if let Some(q)=self.retuned.get(&index) {
                    weight*=q.correction(&out,&mut r.operations);
                }
                r.operations.rank(m);''');p.write_text(s)
p=root/'src/joint_caps/propagated/lazy/strata/messages.rs';s=p.read_text()
s=s.replace('use super::*;','''use super::*;

pub(super) struct TiltedPattern {
    pub pattern:Pattern,
    pub nominal:Arc<Vec<[f64;3]>>,
}
impl TiltedPattern {
    pub fn correction(&self,out:&[u8],ops:&mut crate::rare_tail::budget::Operations)->f64 {
        self.pattern.joint.games.iter().chain(&self.pattern.guide.games).fold(1.,|v,g| {
            ops.guidance+=3;
            let o=out[g.index] as usize;
            v*self.nominal[g.index][o]/g.prob[o]
        })
    }
}''',1)
s=s.replace('-> Option<Pattern>', '-> Option<TiltedPattern>').replace('if !p.omitted.is_empty() || p.nominal.is_some()','if !p.omitted.is_empty()')
s=s.replace('    q.nominal = Some(Arc::new(nominal));\n    Some(q)','    Some(TiltedPattern{pattern:q,nominal:Arc::new(nominal)})')
s=s.replace('self.retuned[&i].mass','self.retuned[&i].pattern.mass').replace('self.retuned[&i].joint','self.retuned[&i].pattern.joint').replace('self.retuned[&i].guide','self.retuned[&i].pattern.guide')
s=s.replace('q.bound_guidance = bounds;', 'q.pattern.bound_guidance = bounds;').replace('let mut uncorrected = q.clone();\n                    uncorrected.nominal = None;', 'let uncorrected = q.pattern.clone();')
s=s.replace('q.joint','q.pattern.joint').replace('q.guide','q.pattern.guide').replace('q.mass','q.pattern.mass')
# The global replacements above also touched the temporary Pattern q in retune.
s=s.replace('q.pattern.mass = p.mass / p.joint.mass * joint.mass;', 'q.mass = p.mass / p.joint.mass * joint.mass;').replace('if q.pattern.mass <= 0. || !q.pattern.mass.is_finite()','if q.mass <= 0. || !q.mass.is_finite()').replace('q.pattern.joint = Arc::new(joint);','q.joint = Arc::new(joint);').replace('q.pattern.guide = Arc::new(guide);','q.guide = Arc::new(guide);')
s=s.replace('q.nominal.as_ref().unwrap()[g.index][o]', 'q.nominal[g.index][o]')
s=s.replace('let w = q.draw(', 'let w = q.pattern.draw(')
s=s.replace('                        if w == 0. {','                        let w=w*q.correction(&out,&mut Default::default());\n                        if w == 0. {')
s=s.replace('        assert!(original.pattern.nominal.is_none());','        assert!(!original.pattern.guide.games.is_empty());')
p.write_text(s)
