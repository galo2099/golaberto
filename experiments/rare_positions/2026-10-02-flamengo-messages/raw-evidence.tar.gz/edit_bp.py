from pathlib import Path
root=Path('/private/tmp/flamengo-tree-experiment/source/odds-rust')
f=root/'src/joint_caps/propagated.rs';s=f.read_text();s=s.replace('    interval_power: f64,','    interval_power: f64,\n    nominal: Option<Arc<Vec<[f64; 3]>>>,')
s=s.replace('interval_power: 1.,','interval_power: 1.,\n                nominal: None,')
s=s.replace('        weight\n    }\n\n    fn counts','''        // Joint and guide probabilities are now under Q. The joint normalizer
        // lives in Pattern.mass; restore the original normalized fixture law.
        if let Some(nominal) = &self.nominal {
            for g in self.joint.games.iter().chain(&self.guide.games).chain(&self.omitted) {
                operations.guidance += 3;
                let o = out[g.index] as usize;
                weight *= nominal[g.index][o] / g.prob[o];
            }
        }
        weight
    }

    fn counts''')
f.write_text(s)
f=root/'src/joint_caps/propagated/lazy.rs';s=f.read_text().replace('interval_power: 1.,','interval_power: 1.,\n                nominal: None,');f.write_text(s)
f=root/'src/joint_caps/propagated/lazy/strata.rs';s=f.read_text().replace('mod tree;','mod tree;\nmod messages;').replace('    cell: Cell,\n    strata:', '    cell: Cell,\n    retuned: HashMap<usize, Pattern>,\n    message_work: usize,\n    strata:')
s=s.replace('        Ok(Self {','        Ok(Self {\n            retuned: HashMap::new(),\n            message_work: 0,')
s=s.replace('let mut pattern = self.strata[index].pattern.clone();','let mut pattern = self.retuned.get(&index).unwrap_or(&self.strata[index].pattern).clone();')
f.write_text(s)
f=root/'src/joint_caps/propagated/lazy/strata/tree.rs';s=f.read_text().replace('        Ok(Self {','        Ok(Self {\n            retuned: HashMap::new(),\n            message_work: 0,');f.write_text(s)
f=root/'examples/branch_stratification.rs';s=f.read_text().replace('    let p = if std::env','    let mut p = if std::env').replace('    for seed in seeds {','    for seed in seeds {\n        p.clear_messages();')
pos='''        let pilot_ms = clock.elapsed().as_secs_f64() * 1000.;'''
s=s.replace(pos,'''        let mut pilots = pilots;
        let message_clock = Instant::now();
        let messages = std::env::var("TREE_MESSAGES").ok().and_then(|s|s.parse::<usize>().ok()).unwrap_or(0);
        let message_info = if messages>0 {
            let rs: Vec<_> = pilots.iter().map(|s|s.0.clone()).collect();
            let info = p.prepare_messages(&m, &rs, messages);
            // Training chooses the proposal; all main/check draws stay fresh.
            pilots = parallel(p.len(), 4, |i| {
                let bounds = guide != "rank";
                let r = p.sample(&m,i,pilot_n,derive(seed,&format!("message-pilot-{i}")),bounds,goals);
                (r.result,bounds,0.)
            });
            info
        } else {serde_json::Value::Null};
        let message_ms = message_clock.elapsed().as_secs_f64()*1000.;
        let pilot_ms = clock.elapsed().as_secs_f64() * 1000.;''')
s=s.replace('"pilot_ms":pilot_ms,"main_ms"','"message_ms":message_ms,"messages":message_info,"pilot_ms":pilot_ms,"main_ms"');f.write_text(s)
