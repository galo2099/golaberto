from pathlib import Path
root=Path('/private/tmp/flamengo-tree-experiment/source/odds-rust')
p=root/'src/rare_tail/branches.rs';s=p.read_text()
s=s.replace('    let nominal_total = if tightened_only {','    let floor = if tree_mode { 50 } else { FLOOR };\n    let nominal_total = if tree_mode { 8000 } else if tightened_only {')
s=s.replace('    let pilot_draws = if tree_mode {','    let pilot_draws = if tree_mode {')
s=s.replace('Ok(p) if p.len() * FLOOR <= nominal_total => p,','Ok(p) if p.len() * floor <= nominal_total => p,')
s=s.replace('        let p = match proposal {','        let mut p = match proposal {')
s=s.replace('pilot_draws * (p.draw_work(m, i, false) + p.draw_work(m, i, true))','pilot_draws * (if tree_mode {p.draw_work(m,i,true)} else {p.draw_work(m, i, false) + p.draw_work(m, i, true)})')
s=s.replace('        let pilots = parallel(p.len(), workers, |i| {','        let mut pilots = parallel(p.len(), workers, |i| {\n            if tree_mode {\n                let interval=p.sample(m,i,pilot_draws,derive(seed,&format!("branch-bound-pilot-{i}")),true,true);\n                let work=interval.result.work;\n                return (interval,true,work);\n            }')
s=s.replace('        let pilot_ms = pilot_clock.elapsed().as_secs_f64() * 1000.;','''        let mut message_info=serde_json::Value::Null;
        if tree_mode {
            let rs=pilots.iter().map(|r|r.0.result.clone()).collect::<Vec<_>>();
            message_info=p.prepare_messages(m,&rs,1);
            let message_work=message_info["work"].as_u64().unwrap() as usize;
            let re_pilot_work=(0..p.len()).map(|i|pilot_draws*p.draw_work(m,i,true)).sum::<usize>();
            if !draw_budget.reserve(message_work+re_pilot_work) {skipped+=1;continue;}
            pilots=parallel(p.len(),workers,|i| {
                let r=p.sample(m,i,pilot_draws,derive(seed,&format!("message-pilot-{i}")),true,true);
                let work=r.result.work;
                (r,true,work)
            });
        }
        let pilot_ms = pilot_clock.elapsed().as_secs_f64() * 1000.;''')
s=s.replace('while total >= p.len() * FLOOR','while total >= p.len() * floor').replace('if total < p.len() * FLOOR','if total < p.len() * floor')
s=s.replace('allocation(&scores, &small, total)','allocation_floor(&scores, &small, total, floor)').replace('allocation(&scores, &small, retry_total)','allocation_floor(&scores, &small, retry_total, floor)')
s=s.replace('"pilot_ms":pilot_ms,"main_ms"','"messages":message_info,"pilot_ms":pilot_ms,"main_ms"')
# Existing native allocation remains byte-equivalent.
s=s.replace('fn allocation(scores: &[f64], small: &[bool], total: usize) -> Option<Vec<usize>> {','''fn allocation(scores: &[f64], small: &[bool], total: usize) -> Option<Vec<usize>> {
    allocation_floor(scores,small,total,FLOOR)
}
fn allocation_floor(scores: &[f64], small: &[bool], total: usize, floor: usize) -> Option<Vec<usize>> {''').replace('if s { 2 } else { FLOOR }','if s { 2 } else { floor }')
p.write_text(s)
p=root/'src/joint_caps/propagated/lazy/strata.rs';s=p.read_text().replace('        let p = &self.strata[index].pattern;\n        let needed','        let p = self.retuned.get(&index).unwrap_or(&self.strata[index].pattern);\n        let needed').replace('        8 * (p.omitted.len() + p.joint.games.len())','        3 * usize::from(p.nominal.is_some()) * (p.joint.games.len()+p.guide.games.len())\n            + 8 * (p.omitted.len() + p.joint.games.len())');p.write_text(s)
p=root/'src/joint_caps/propagated/lazy/strata/messages.rs';s=p.read_text().replace('            let mut expected=0.;','''            let mut expected=0.;
            for mut code in 0..3usize.pow(m.fixtures.len() as u32) {
                let mut out=vec![0;m.fixtures.len()];let mut raw=1.;
                for (i,g) in m.fixtures.iter().enumerate() {let o=code%3;code/=3;out[i]=o as u8;raw*=g.prob[o];}
                if canonical_ranks(&m,&out)[cell.team]==rank {expected+=raw;}
            }''').replace('                        if !bounds {expected+=raw;}','                        let _=raw;');p.write_text(s)
