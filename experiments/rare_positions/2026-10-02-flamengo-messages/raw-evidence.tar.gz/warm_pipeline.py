from pathlib import Path
p=Path('/private/tmp/flamengo-tree-experiment/source/odds-rust/src/rare_tail/branches.rs');s=p.read_text()
anchor='const TOTAL: usize = 30000;'
s=s.replace(anchor,'''type Pilot = (BranchSample,bool,u64);
pub(super) struct Prepared {
    cell:Cell,
    p:BranchStrata,
    ms:f64,
    pilots:Vec<Pilot>,
    message:serde_json::Value,
    units:usize,
    work:u64,
}
fn prepare(m:&Model,cell:Cell,seed:i64,pilot:usize)->std::result::Result<Prepared,String> {
    let clock=Instant::now();
    let mut p=BranchStrata::with_tree(m,cell,seed,4,64,0,4000000)?;
    let mut pilots:Vec<_>=(0..p.len()).map(|i| {
        let r=p.sample(m,i,pilot,derive(seed,&format!("branch-bound-pilot-{i}")),true,true);
        let work=r.result.work;(r,true,work)
    }).collect();
    let mut units=p.setup_work()+pilots.iter().map(|r|r.0.result.operations.units()).sum::<usize>();
    let mut work=pilots.iter().map(|r|r.2).sum();
    let rs=pilots.iter().map(|r|r.0.result.clone()).collect::<Vec<_>>();
    let message=p.prepare_messages(m,&rs,1);
    units+=message["work"].as_u64().unwrap() as usize;
    for i in message["selected"].as_array().unwrap().iter().map(|v|v.as_u64().unwrap() as usize) {
        let r=p.sample(m,i,pilot,derive(seed,&format!("message-pilot-{i}")),true,true);
        units+=r.result.operations.units();work+=r.result.work;
        let work=r.result.work;pilots[i]=(r,true,work);
    }
    Ok(Prepared{cell,p,ms:clock.elapsed().as_secs_f64()*1000.,pilots,message,units,work})
}
'''+anchor)
s=s.replace('prepared: &mut Vec<(Cell, BranchStrata, f64)>','prepared: &mut Vec<Prepared>')
old='''                                    let clock = Instant::now();
                                    let result = BranchStrata::with_tree(
                                        m, cell, seed, 4, 64, 0, 4000000,
                                    );
                                    (result, clock.elapsed().as_secs_f64() * 1000.)'''
# Actual formatted closure may differ. Replace from spawn closure to ending marker.
a=s.index('scope.spawn(move || {');b=s.index('}),',a)
s=s[:a]+'''scope.spawn(move || {
                                    prepare(m,cell,seed,std::env::var("RUST_ODDS_EXPERIMENT_TREE_PILOT").ok().and_then(|v|v.parse().ok()).unwrap_or(50))
                                '''+s[b:]
s=s.replace('''            let mut preparation_ms = 0.;
            let mut prebuilt = false;''','''            let mut preparation_ms = 0.;
            let mut trained=None;
            let mut trained_message=serde_json::Value::Null;
            let mut trained_units=0;
            let mut prebuilt = false;''')
a=s.index('                if let Some(slot) = prepared.iter().position(');b=s.index('                } else {',a)
s=s[:a]+'''                if let Some(slot)=prepared.iter().position(|v|v.cell==cell) {
                    let ready=prepared.remove(slot);
                    preparation_ms=ready.ms;prebuilt=true;trained=Some(ready.pilots);trained_message=ready.message;trained_units=ready.units;work+=ready.work;
                    Ok(ready.p)
'''+s[b:]
# Join after the next native constructor, restoring all four sampling workers.
needle='''            if !deterministic && start.elapsed().as_secs_f64() * 1000. >= allowance {'''
s=s.replace(needle,'''            if let Some((c,handle))=preparation.take() {
                match handle.join().unwrap() {
                    Ok(ready)=>prepared.push(ready),
                    Err(reason)=>emit(log,"rust_odds_tree_preparation_skip",json!({"team":m.ids[c.team],"rank":c.rank+1,"reason":reason})),
                }
                search_workers=workers;
            }
'''+needle,1)
s=s.replace('''            let pilot_cost = if budget::modeled() {''','''            let pilot_cost = if prebuilt {trained_units} else if budget::modeled() {''')
s=s.replace('''            let mut pilots = parallel(p.len(), search_workers, |i| {''','''            let mut pilots = if let Some(rows)=trained {rows} else { parallel(p.len(), search_workers, |i| {''')
a=s.index('            let mut pilots = if let Some(rows)=trained');b=s.index('            if tree_mode && budget::modeled()',a)
s=s[:b].rstrip().removesuffix('});')+'}) };\n'+s[b:]
s=s.replace('            if tree_mode && budget::modeled() {','            if tree_mode && !prebuilt && budget::modeled() {',1)
s=s.replace('''            let mut message_info = serde_json::Value::Null;
            if tree_mode {''','''            let mut message_info = trained_message;
            if tree_mode && !prebuilt {''')
# Build both fixed, independently seeded final batches concurrently only for trees.
a=s.index('            let main_clock = Instant::now();');b=s.index('            work += main.work + check.work;',a)
old=s[a:b]
new='''            let (main,check,main_ms,check_ms)=if tree_mode {
                let clock=Instant::now();
                let costs:Vec<_>=(0..2*p.len()).map(|slot| {let i=order[slot%p.len()];ns[i]*p.draw_work(m,i,guides[i])}).collect();
                let mut rows=budget::parallel(&costs,search_workers,|slot| {
                    let phase=if slot<p.len(){"main"}else{"check"};let i=order[slot%p.len()];
                    (slot/p.len(),i,p.sample(m,i,ns[i],derive(seed,&format!("branch-{phase}-{i}")),guides[i],true))
                });
                rows.sort_by_key(|r|(r.0,r.1));
                let mut rows:Vec<_>=rows.into_iter().map(|r|r.2).collect();
                let checks=rows.split_off(p.len());
                (combine_branches(&rows),combine_branches(&checks),clock.elapsed().as_secs_f64()*1000.,0.)
            } else {
'''+old+'''                (main,check,main_ms,check_ms)
            };
'''
s=s[:a]+new+s[b:]
s=s.replace('"prebuilt":prebuilt,','"parallel_pair":tree_mode,"prebuilt":prebuilt,')
# Final join if no native proposal reached the normal constructor boundary.
a=s.index('        if let Some((cell, handle)) = preparation {');b=s.index('    });',a)
s=s[:a]+'''        if let Some((cell,handle))=preparation {
            match handle.join().unwrap() {
                Ok(ready)=>prepared.push(ready),
                Err(reason)=>emit(log,"rust_odds_tree_preparation_skip",json!({"team":m.ids[cell.team],"rank":cell.rank+1,"reason":reason})),
            }
        }
'''+s[b:]
p.write_text(s)
