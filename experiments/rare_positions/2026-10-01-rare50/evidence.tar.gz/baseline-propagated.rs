//! Joint conditioning on a complete, bounded union of propagated target paths.
//! Every restriction is necessary for the requested packed rank. Exhausting a
//! setup budget skips this proposal; it never establishes impossibility.
use super::{broad::TerminalTable, choose};
use crate::{
    conditioned::{Result, ScoreContext},
    domains::Domains,
    lookahead::{RankGame, Suffix},
    model::{Key, Model},
    pool::work_per_sample,
    rng::Rng,
    search::Cell,
};
use serde_json::json;
use std::{collections::HashMap, sync::Arc};

const PATTERN_LIMIT: usize = 64;
const BASE_SHARE: f64 = 1e-6;

struct JointPattern {
    outcomes: Vec<u8>,
    added: Vec<usize>,
    cumulative: f64,
}
struct NecessaryJoint {
    games: Vec<RankGame>,
    internal: Vec<(RankGame, usize, usize)>,
    tables: Vec<TerminalTable>,
    patterns: Vec<JointPattern>,
    mass: f64,
    selected: Vec<usize>,
    states: usize,
    residual_hint: f64,
}
impl NecessaryJoint {
    fn new(
        games: &[RankGame],
        base: &[i32],
        lower: &[i32],
        upper: &[i32],
        limit: usize,
        budget: usize,
    ) -> Option<(Self, Vec<RankGame>)> {
        let terminal = |t: usize| {
            let team_games = games.iter().filter(|g| g.home == t || g.away == t);
            let span: i32 = team_games
                .map(|g| {
                    *if g.home == t { &g.hg } else { &g.ag }
                        .iter()
                        .max()
                        .unwrap()
                })
                .sum();
            (0..=span)
                .map(|gain| {
                    if base[t] + gain >= lower[t] && base[t] + gain <= upper[t] {
                        1.
                    } else {
                        0.
                    }
                })
                .collect::<Vec<_>>()
        };
        let mut candidates = (0..base.len())
            .filter_map(|t| {
                if lower[t] <= i32::MIN / 8 && upper[t] >= i32::MAX / 8 {
                    return None;
                }
                let table = TerminalTable::new(
                    games
                        .iter()
                        .copied()
                        .filter(|g| g.home == t || g.away == t)
                        .collect(),
                    t,
                    terminal(t),
                );
                let mass = table.mass(0);
                (mass < 1. - 1e-12).then_some((t, mass))
            })
            .collect::<Vec<_>>();
        candidates.sort_by(|a, b| a.1.total_cmp(&b.1).then(a.0.cmp(&b.0)));
        let mut selected = Vec::new();
        for &(t, _) in &candidates {
            if selected.len() >= limit {
                break;
            }
            selected.push(t);
            let states = games
                .iter()
                .filter(|g| selected.contains(&g.home) && selected.contains(&g.away))
                .try_fold(1usize, |n, g| {
                    n.checked_mul(g.prob.iter().filter(|&&p| p > 0.).count())
                });
            if states.is_none_or(|n| n > 12000) {
                selected.pop();
            }
        }
        let residual_hint = candidates
            .iter()
            .filter(|(t, _)| !selected.contains(t))
            .map(|(_, p)| *p)
            .product();
        let mut internal = Vec::new();
        let mut external = vec![Vec::new(); selected.len()];
        let mut remaining = Vec::new();
        let mut fixed = Vec::new();
        for &g in games {
            match (
                selected.iter().position(|&t| t == g.home),
                selected.iter().position(|&t| t == g.away),
            ) {
                (Some(h), Some(a)) => {
                    internal.push((g, h, a));
                    fixed.push(g);
                }
                (Some(t), None) | (None, Some(t)) => {
                    external[t].push(g);
                    fixed.push(g);
                }
                _ => remaining.push(g),
            }
        }
        let tables = selected
            .iter()
            .zip(external)
            .map(|(&t, gs)| TerminalTable::new(gs, t, terminal(t)))
            .collect::<Vec<_>>();
        let mut future_min = vec![vec![0usize; selected.len()]; internal.len() + 1];
        let mut future_max = future_min.clone();
        for i in (0..internal.len()).rev() {
            future_min[i] = future_min[i + 1].clone();
            future_max[i] = future_max[i + 1].clone();
            let (g, h, a) = &internal[i];
            for (t, gain) in [(*h, g.hg), (*a, g.ag)] {
                future_min[i][t] += (0..3)
                    .filter(|&o| g.prob[o] > 0.)
                    .map(|o| gain[o] as usize)
                    .min()
                    .unwrap();
                future_max[i][t] += (0..3)
                    .filter(|&o| g.prob[o] > 0.)
                    .map(|o| gain[o] as usize)
                    .max()
                    .unwrap();
            }
        }
        let mut nodes = 0usize;
        let mut states = vec![(Vec::new(), vec![0usize; selected.len()], 1.)];
        for (step, (g, h, a)) in internal.iter().enumerate() {
            let mut next = Vec::new();
            for (outcomes, added, mass) in states {
                for o in 0..3 {
                    if g.prob[o] <= 0. {
                        continue;
                    }
                    if nodes == budget {
                        return None;
                    }
                    nodes += 1;
                    if nodes > 20000 {
                        let (mut joint, remaining) = Self::new(
                            games,
                            base,
                            lower,
                            upper,
                            selected.len().saturating_sub(1),
                            budget - nodes,
                        )?;
                        joint.states += nodes;
                        return Some((joint, remaining));
                    }
                    let mut added = added.clone();
                    added[*h] += g.hg[o] as usize;
                    added[*a] += g.ag[o] as usize;
                    let possible = selected.iter().enumerate().all(|(i, &t)| {
                        let lo = added[i] + future_min[step + 1][i];
                        let hi = added[i] + future_max[step + 1][i];
                        if upper[t] >= i32::MAX / 8 {
                            tables[i].mass(hi) > 0.
                        } else if lower[t] <= i32::MIN / 8 {
                            tables[i].mass(lo) > 0.
                        } else {
                            (lo..=hi).any(|a| tables[i].mass(a) > 0.)
                        }
                    });
                    if !possible {
                        continue;
                    }
                    let mut outcomes = outcomes.clone();
                    outcomes.push(o as u8);
                    next.push((outcomes, added, mass * g.prob[o]));
                }
            }
            states = next;
        }
        let count = nodes;
        if std::env::var("RUST_ODDS_PROPAGATED_ORDER").as_deref() != Ok("fixture") {
            let difficulty = |g: &RankGame| {
                let mass = |t| candidates.iter().find(|v| v.0 == t).map_or(1., |v| v.1);
                mass(g.home) * mass(g.away)
            };
            remaining.sort_by(|a, b| {
                difficulty(a)
                    .total_cmp(&difficulty(b))
                    .then(a.index.cmp(&b.index))
            });
        }
        let mut mass = 0.;
        let mut patterns = Vec::new();
        for (outcomes, added, probability) in states {
            let weight = tables
                .iter()
                .zip(&added)
                .fold(probability, |p, (t, &a)| p * t.mass(a));
            if weight > 0. {
                mass += weight;
                patterns.push(JointPattern {
                    outcomes,
                    added,
                    cumulative: mass,
                });
            }
        }
        Some((
            Self {
                games: fixed,
                internal,
                tables,
                patterns,
                mass,
                selected,
                states: count,
                residual_hint,
            },
            remaining,
        ))
    }
    fn sample(&self, rng: &mut Rng, out: &mut [u8]) {
        let u = rng.float() * self.mass;
        let p = &self.patterns[self
            .patterns
            .partition_point(|p| p.cumulative < u)
            .min(self.patterns.len() - 1)];
        for ((g, _, _), &o) in self.internal.iter().zip(&p.outcomes) {
            out[g.index] = o;
        }
        for (table, &added) in self.tables.iter().zip(&p.added) {
            table.sample(added, rng, out);
        }
    }
}

struct Guide {
    games: Vec<RankGame>,
    cdf: Suffix,
    reverse: Suffix,
    min: Vec<Vec<i32>>,
    max: Vec<Vec<i32>>,
    origin: Vec<Vec<i32>>,
}
impl Guide {
    fn new(games: Vec<RankGame>, teams: usize) -> Self {
        let mut min = vec![vec![0; teams]; games.len() + 1];
        let mut max = min.clone();
        let mut reversed = games.clone();
        for i in (0..games.len()).rev() {
            min[i] = min[i + 1].clone();
            max[i] = max[i + 1].clone();
            let g = &games[i];
            for (t, gains) in [(g.home, g.hg), (g.away, g.ag)] {
                let lo = (0..3)
                    .filter(|&o| g.prob[o] > 0.)
                    .map(|o| gains[o])
                    .min()
                    .unwrap();
                let hi = (0..3)
                    .filter(|&o| g.prob[o] > 0.)
                    .map(|o| gains[o])
                    .max()
                    .unwrap();
                min[i][t] += lo;
                max[i][t] += hi;
                // Zero-mass options can have gains above hi. Keep arithmetic
                // nonnegative even though those options do not contribute.
                let top = *gains.iter().max().unwrap();
                if t == g.home {
                    reversed[i].hg = gains.map(|v| top - v);
                } else {
                    reversed[i].ag = gains.map(|v| top - v);
                }
            }
        }
        let span = max[0].iter().copied().max().unwrap_or(0);
        // Reverse gains use the unconditional per-fixture maximum. Store that
        // complement's origin separately from the actual attainable maximum.
        let mut origin = vec![vec![0; teams]; games.len() + 1];
        for i in (0..games.len()).rev() {
            origin[i] = origin[i + 1].clone();
            origin[i][games[i].home] += *games[i].hg.iter().max().unwrap();
            origin[i][games[i].away] += *games[i].ag.iter().max().unwrap();
        }
        let reverse_span = origin[0].iter().copied().max().unwrap_or(0);
        let cdf = Suffix::new(&games, teams, span);
        let reverse = Suffix::new(&reversed, teams, reverse_span);
        Self {
            games,
            cdf,
            reverse,
            min,
            max,
            origin,
        }
    }
    fn factor(&self, step: usize, team: usize, cap: i32, below: f64, above: f64) -> f64 {
        let origin = self.origin[step][team];
        // When guidance weights one side and ties equally, the whole factor
        // is one inclusive tail. Avoid three separate DP lookups and retain
        // tiny upper tails without CDF subtraction.
        if below == 0. && above == 1. {
            return self.reverse.cdf(step, team, origin - cap);
        }
        if below == 1. && above == 0. {
            return self.cdf.cdf(step, team, cap);
        }
        let low = self.cdf.cdf(step, team, cap - 1);
        // Evaluate a rare upper tail directly, never as 1 - rounded CDF.
        let high = self.reverse.cdf(step, team, origin - cap - 1);
        let tie = if low <= 0.5 {
            self.cdf.cdf(step, team, cap) - low
        } else {
            self.reverse.cdf(step, team, origin - cap) - high
        };
        below * low + tie.max(0.) + above * high
    }
}
struct Pattern {
    fixed: Vec<(usize, u8)>,
    base: Vec<i32>,
    lower: Vec<i32>,
    upper: Vec<i32>,
    guide: Arc<Guide>,
    joint: Arc<NecessaryJoint>,
    mass: f64,
    tilt: f64,
    cumulative: f64,
}
impl Pattern {
    fn counts(&self, step: usize, points: &[i32], cell: Cell) -> Option<(usize, usize)> {
        let target = points[cell.team];
        let mut above = 0;
        let mut below = 0;
        for (t, &value) in points.iter().enumerate() {
            if t != cell.team {
                let lo = value + self.guide.min[step][t];
                let hi = value + self.guide.max[step][t];
                if lo > self.upper[t] || hi < self.lower[t] {
                    return None;
                }
                above += usize::from(lo > target);
                below += usize::from(hi < target);
            }
        }
        (above <= cell.rank && below <= points.len() - 1 - cell.rank).then_some((above, below))
    }
    fn next_counts(
        &self,
        step: usize,
        points: &[i32],
        cell: Cell,
        o: usize,
        counts: (usize, usize),
    ) -> Option<(usize, usize)> {
        let g = &self.guide.games[step];
        let target = points[cell.team];
        let (mut above, mut below) = counts;
        for (t, gain) in [(g.home, g.hg[o]), (g.away, g.ag[o])] {
            above -= usize::from(points[t] + self.guide.min[step][t] > target);
            below -= usize::from(points[t] + self.guide.max[step][t] < target);
            let lo = points[t] + gain + self.guide.min[step + 1][t];
            let hi = points[t] + gain + self.guide.max[step + 1][t];
            if lo > self.upper[t] || hi < self.lower[t] {
                return None;
            }
            above += usize::from(lo > target);
            below += usize::from(hi < target);
        }
        (above <= cell.rank && below <= points.len() - 1 - cell.rank).then_some((above, below))
    }
    #[cfg(test)]
    fn allows(&self, step: usize, points: &[i32], cell: Cell, outcome: usize) -> bool {
        let g = &self.guide.games[step];
        let target = points[cell.team];
        let mut above = 0;
        let mut below = 0;
        for (t, &value) in points.iter().enumerate() {
            if t == cell.team {
                continue;
            }
            let value = value
                + if t == g.home {
                    g.hg[outcome]
                } else if t == g.away {
                    g.ag[outcome]
                } else {
                    0
                };
            let lo = value + self.guide.min[step + 1][t];
            let hi = value + self.guide.max[step + 1][t];
            if lo > self.upper[t] || hi < self.lower[t] {
                return false;
            }
            above += usize::from(lo > target);
            below += usize::from(hi < target);
        }
        above <= cell.rank && below <= points.len() - 1 - cell.rank
    }
}
pub struct PropagatedJoint {
    cell: Cell,
    patterns: Vec<Pattern>,
    mass: f64,
    tilted_mass: f64,
    target_patterns: usize,
    guides: usize,
}
impl PropagatedJoint {
    pub fn new(m: &Model, cell: Cell) -> Option<Self> {
        Self::with_limits(m, cell, 4, 6)
    }
    fn with_limits(
        m: &Model,
        cell: Cell,
        minimum_forced: usize,
        rival_limit: usize,
    ) -> Option<Self> {
        let rules = &m.request.phase.championship;
        if m.keys.first() != Some(&Key::Pt)
            || m.request.phase.bonus_points != 0
            || (rules.point_win, rules.point_draw, rules.point_loss) != (3, 1, 0)
            || m.ids.len() != m.n
            || cell.team >= m.n
            || cell.rank >= m.n
            || m.fixtures.iter().any(|g| g.home == g.away)
        {
            return None;
        }
        let mut left = vec![0; m.n];
        for g in &m.fixtures {
            left[g.home] += 1;
            left[g.away] += 1;
        }
        let wins = m.keys.get(1) == Some(&Key::W);
        let stride64 = if wins {
            m.base
                .iter()
                .zip(&left)
                .map(|(c, n)| i64::from(c.wins) + i64::from(*n))
                .max()?
                + 1
        } else {
            1
        };
        if !(1..=4096).contains(&stride64) {
            return None;
        }
        let stride = stride64 as i32;
        if m.fixtures.len() > 256
            || left[cell.team] == 0
            || left[cell.team] > 32
            || left
                .iter()
                .any(|&n| (3 * stride64 + i64::from(wins)) * i64::from(n) > 4096)
            || m.base.iter().any(|c| {
                (i64::from(c.points).abs() + 3 * m.fixtures.len() as i64 + 1) * stride64
                    + i64::from(c.wins)
                    >= i64::from(i32::MAX / 4)
            })
        {
            return None;
        }
        let base = m
            .base
            .iter()
            .map(|c| c.points * stride + if wins { c.wins } else { 0 })
            .collect::<Vec<_>>();
        let hg = [0, stride, 3 * stride + i32::from(wins)];
        let all = m
            .fixtures
            .iter()
            .enumerate()
            .map(|(index, g)| RankGame {
                index,
                home: g.home,
                away: g.away,
                prob: g.prob,
                hg,
                ag: [hg[2], hg[1], hg[0]],
            })
            .collect::<Vec<_>>();
        let (target_games, remaining): (Vec<_>, Vec<_>) = all
            .into_iter()
            .partition(|g| g.home == cell.team || g.away == cell.team);
        let span = (hg[2] * left[cell.team]) as usize + 1;
        let terminal = (0..span)
            .map(|gain| {
                let total = base[cell.team] + gain as i32;
                let above = (0..m.n)
                    .filter(|&t| t != cell.team && base[t] > total)
                    .count();
                let below = (0..m.n)
                    .filter(|&t| t != cell.team && base[t] + hg[2] * left[t] < total)
                    .count();
                if above <= cell.rank && below <= m.n - 1 - cell.rank {
                    1.
                } else {
                    0.
                }
            })
            .collect::<Vec<_>>();
        let table = TerminalTable::new(target_games, cell.team, terminal);
        // Count every supported target assignment, with saturation. The model
        // is used only if the entire union fits; no prefix is silently retained.
        let mut counts = vec![vec![0usize; span]; table.games.len() + 1];
        for (i, &p) in table.rows.last()?.iter().enumerate() {
            counts[table.games.len()][i] = usize::from(p > 0.);
        }
        for i in (0..table.games.len()).rev() {
            let g = &table.games[i];
            let gains = if g.home == cell.team { g.hg } else { g.ag };
            for added in 0..span {
                for o in 0..3 {
                    if g.prob[o] > 0. {
                        counts[i][added] = (counts[i][added]
                            + counts[i + 1]
                                .get(added + gains[o] as usize)
                                .copied()
                                .unwrap_or(0))
                        .min(PATTERN_LIMIT + 1);
                    }
                }
            }
        }
        let target_patterns = counts[0][0];
        if target_patterns == 0 || target_patterns > PATTERN_LIMIT {
            return None;
        }
        let mut assignments = vec![(0usize, Vec::new(), 1., base.clone())];
        for (step, g) in table.games.iter().enumerate() {
            let mut next = Vec::new();
            let gain = if g.home == cell.team { g.hg } else { g.ag };
            for (added, fixed, mass, points) in assignments {
                for o in 0..3 {
                    let to = added + gain[o] as usize;
                    if g.prob[o] <= 0. || counts[step + 1].get(to).copied().unwrap_or(0) == 0 {
                        continue;
                    }
                    let mut fixed = fixed.clone();
                    fixed.push((g.index, o as u8));
                    let mut points = points.clone();
                    points[g.home] += g.hg[o];
                    points[g.away] += g.ag[o];
                    next.push((to, fixed, mass * g.prob[o], points));
                }
            }
            assignments = next;
        }
        let rivals = (0..m.n).filter(|&t| t != cell.team).collect::<Vec<_>>();
        let mut patterns = Vec::new();
        let mut cache: HashMap<(Vec<u8>, Vec<(i32, i32)>), (Arc<NecessaryJoint>, Arc<Guide>)> =
            HashMap::new();
        let mut setup_nodes = 0usize;
        let mut guide_values = 0usize;
        let mut mass = 0.;
        for (_, mut fixed, mut weight, points) in assignments {
            let d = Domains::propagate(&remaining, &points, &rivals, cell.rank, points[cell.team]);
            if !d.feasible {
                continue;
            }
            let mut variables = Vec::new();
            for (g, &mask) in remaining.iter().zip(&d.domains) {
                if mask.count_ones() == 1 {
                    let o = mask.trailing_zeros() as usize;
                    fixed.push((g.index, o as u8));
                    weight *= g.prob[o];
                } else {
                    let total: f64 = (0..3)
                        .filter(|o| mask & (1 << o) != 0)
                        .map(|o| g.prob[o])
                        .sum();
                    if total <= 0. {
                        return None;
                    }
                    weight *= total;
                    let mut g = *g;
                    g.prob = std::array::from_fn(|o| {
                        if mask & (1 << o) != 0 {
                            g.prob[o] / total
                        } else {
                            0.
                        }
                    });
                    variables.push(g);
                }
            }
            if fixed.len() < table.games.len() + minimum_forced {
                return None;
            }
            let propagated_base = if d.base.is_empty() { points } else { d.base };
            let constraint_key = (0..m.n)
                .map(|t| {
                    let span: i32 = variables
                        .iter()
                        .filter(|g| g.home == t || g.away == t)
                        .map(|g| {
                            *if g.home == t { &g.hg } else { &g.ag }
                                .iter()
                                .max()
                                .unwrap()
                        })
                        .sum();
                    (
                        (d.lower[t] - propagated_base[t]).clamp(0, span + 1),
                        (d.upper[t] - propagated_base[t]).clamp(-1, span),
                    )
                })
                .collect::<Vec<_>>();
            if minimum_forced > 0 && patterns.len() >= 16 {
                return None;
            }
            let key = (d.domains.clone(), constraint_key);
            let (joint, guide) = if let Some(pair) = cache.get(&key) {
                pair.clone()
            } else {
                let (joint, variables) = NecessaryJoint::new(
                    &variables,
                    &propagated_base,
                    &d.lower,
                    &d.upper,
                    rival_limit,
                    60000 - setup_nodes,
                )?;
                setup_nodes += joint.states;
                let span = (0..m.n)
                    .map(|t| {
                        variables
                            .iter()
                            .filter(|g| g.home == t || g.away == t)
                            .map(|g| {
                                *if g.home == t { &g.hg } else { &g.ag }
                                    .iter()
                                    .max()
                                    .unwrap()
                            })
                            .sum::<i32>()
                    })
                    .max()
                    .unwrap_or(0) as usize
                    + 1;
                // Suffix rows share unchanged teams through Arc. Two
                // endpoint rows per fixture, in both gain directions.
                guide_values += (2 * variables.len() + 1) * span * 2;
                if guide_values > 4000000 {
                    return None;
                }
                let pair = (Arc::new(joint), Arc::new(Guide::new(variables, m.n)));
                cache.insert(key, pair.clone());
                pair
            };
            if joint.mass <= 0. {
                continue;
            }
            weight *= joint.mass;
            mass += weight;
            patterns.push(Pattern {
                fixed,
                base: propagated_base,
                lower: d.lower,
                upper: d.upper,
                guide,
                joint,
                mass: weight,
                tilt: 1.,
                cumulative: mass,
            });
        }
        if mass <= 0.
            || !mass.is_finite()
            || patterns.is_empty()
            || patterns
                .iter()
                .any(|p| p.fixed.len() < table.games.len() + minimum_forced)
        {
            return None;
        }
        let max_hint = patterns
            .iter()
            .map(|p| p.joint.residual_hint)
            .fold(0., f64::max);
        let mut tilted_mass = 0.;
        for p in &mut patterns {
            p.tilt = if max_hint > 0. {
                (p.joint.residual_hint / max_hint).max(1e-6)
            } else {
                1.
            };
            tilted_mass += p.mass * p.tilt;
            p.cumulative = tilted_mass;
        }
        Some(Self {
            tilted_mass,
            guides: cache.len(),
            cell,
            patterns,
            mass,
            target_patterns,
        })
    }
    pub fn describe(&self, m: &Model) -> serde_json::Value {
        json!({"mode":"propagated_target_union","team":m.ids[self.cell.team],"rank":self.cell.rank+1,
            "target_patterns":self.target_patterns,"feasible_patterns":self.patterns.len(),"guides":self.guides,
            "forced_min":self.patterns.iter().map(|p|p.fixed.len()).min(),"forced_max":self.patterns.iter().map(|p|p.fixed.len()).max(),
            "conditioning_mass":self.mass,"variable_max":self.patterns.iter().map(|p|p.guide.games.len()).max(),
            "joint_states":self.patterns.iter().map(|p|p.joint.states).sum::<usize>(),
            "case_tilts":self.patterns.iter().map(|p|json!({"total":p.base[self.cell.team],"mass":p.mass,"tilt":p.tilt,"hint":p.joint.residual_hint})).collect::<Vec<_>>(),
            "joint_teams":self.patterns.iter().map(|p|p.joint.selected.iter().map(|&t|m.ids[t]).collect::<Vec<_>>()).collect::<Vec<_>>()})
    }
    pub fn sample(&self, m: &Model, samples: usize, seed: i64, guided: bool) -> Result {
        let mut result = Result {
            mass: self.mass,
            ..Default::default()
        };
        let mut rng = Rng::new(seed);
        let mut scores = ScoreContext::new(m);
        let mut out = vec![0; m.fixtures.len()];
        let mut points = vec![0; m.n];
        let (mut sum, mut sum2, mut largest, mut batches) = (0., 0., 0_f64, [0.; 2]);
        for draw in 0..samples {
            let u = rng.float() * self.tilted_mass;
            let p = &self.patterns[self
                .patterns
                .partition_point(|p| p.cumulative < u)
                .min(self.patterns.len() - 1)];
            for &(i, o) in &p.fixed {
                out[i] = o;
            }
            points.copy_from_slice(&p.base);
            p.joint.sample(&mut rng, &mut out);
            for g in &p.joint.games {
                let o = out[g.index] as usize;
                points[g.home] += g.hg[o];
                points[g.away] += g.ag[o];
            }
            let target = points[self.cell.team];
            let Some(mut counts) = p.counts(0, &points, self.cell) else {
                result.samples += 1;
                continue;
            };
            let mut ea = 0.;
            let mut eb = 0.;
            for t in 0..m.n {
                if t != self.cell.team {
                    ea += p.guide.factor(0, t, target - points[t], 0., 1.);
                    eb += p.guide.factor(0, t, target - points[t], 1., 0.);
                }
            }
            let above = if ea > 0. {
                (self.cell.rank as f64 / ea).min(1.).powi(6)
            } else {
                1.
            };
            let below = if eb > 0. {
                ((m.n - 1 - self.cell.rank) as f64 / eb).min(1.).powi(6)
            } else {
                1.
            };
            let mut weight = self.tilted_mass / self.mass / p.tilt;
            for (step, g) in p.guide.games.iter().enumerate() {
                let mut q = [0.; 3];
                let mut support = 0.;
                let next: [Option<(usize, usize)>; 3] =
                    std::array::from_fn(|o| p.next_counts(step, &points, self.cell, o, counts));
                let allowed: [bool; 3] =
                    std::array::from_fn(|o| g.prob[o] > 0. && next[o].is_some());
                for o in 0..3 {
                    if !allowed[o] {
                        continue;
                    }
                    support += g.prob[o];
                    q[o] = g.prob[o]
                        * if guided {
                            p.guide.factor(
                                step + 1,
                                g.home,
                                target - points[g.home] - g.hg[o],
                                below,
                                above,
                            ) * p.guide.factor(
                                step + 1,
                                g.away,
                                target - points[g.away] - g.ag[o],
                                below,
                                above,
                            )
                        } else {
                            1.
                        };
                }
                let guide_mass = q.iter().sum::<f64>();
                for o in 0..3 {
                    if !allowed[o] {
                        continue;
                    }
                    q[o] = if guide_mass > 0. {
                        (1. - BASE_SHARE) * q[o] + BASE_SHARE * guide_mass * g.prob[o] / support
                    } else {
                        g.prob[o]
                    };
                }
                let total = q.iter().sum();
                if total <= 0. {
                    weight = 0.;
                    break;
                }
                let o = choose(q, total, &mut rng);
                counts = next[o].unwrap();
                weight *= g.prob[o] * total / q[o];
                out[g.index] = o as u8;
                points[g.home] += g.hg[o];
                points[g.away] += g.ag[o];
            }
            result.samples += 1;
            if weight <= 0. || scores.rank(self.cell.team, &out, &mut rng, None) != self.cell.rank {
                continue;
            }
            result.hits += 1;
            if result.witness.is_none() {
                result.witness = Some(out.clone());
            }
            sum += weight;
            sum2 += weight * weight;
            largest = largest.max(weight);
            batches[usize::from(draw >= samples / 2)] += weight;
        }
        result.work = result.samples as u64 * work_per_sample(m);
        result.summarize(sum, sum2, largest, batches);
        result
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{conditioned::canonical_ranks, model::Request};
    fn league(sort: &str) -> Model {
        let games = (0..4)
            .flat_map(|h| {
                (h + 1..4).map(move |a| {
                    json!({"id":h*4+a,"home_id":h,"away_id":a,
            "home_power":1.1+0.1*h as f64,"away_power":0.8+0.1*a as f64})
                })
            })
            .collect::<Vec<_>>();
        let request: Request = serde_json::from_value(json!({"id":1,
            "phase":{"sort":sort,"championship":{"point_win":3,"point_draw":1,"point_loss":0}},
            "team_groups":(0..4).map(|t|json!({"team_id":t,"add_sub":t,"bias":t})).collect::<Vec<_>>(),
            "games":games})).unwrap();
        Model::new(request).unwrap()
    }
    fn exact(m: &Model, p: &PropagatedJoint) -> (f64, f64) {
        let stride = if m.keys.get(1) == Some(&Key::W) { 4 } else { 1 };
        let mut event = 0.;
        let mut rank = 0.;
        for mut code in 0..3usize.pow(m.fixtures.len() as u32) {
            let mut out = vec![0; m.fixtures.len()];
            let mut mass = 1.;
            let mut points = m
                .base
                .iter()
                .map(|c| c.points * stride + if stride > 1 { c.wins } else { 0 })
                .collect::<Vec<_>>();
            for (i, g) in m.fixtures.iter().enumerate() {
                let o = code % 3;
                code /= 3;
                out[i] = o as u8;
                mass *= g.prob[o];
                let gains = [0, stride, 3 * stride + i32::from(stride > 1)];
                points[g.home] += gains[o];
                points[g.away] += gains[2 - o];
            }
            let hit = canonical_ranks(m, &out)[p.cell.team] == p.cell.rank;
            if hit {
                rank += mass;
            }
            let pattern = p
                .patterns
                .iter()
                .find(|p| p.fixed.iter().all(|&(i, o)| out[i] == o));
            let Some(pattern) = pattern else {
                assert!(!hit, "lost target/forced support");
                continue;
            };
            let supported = pattern
                .joint
                .games
                .iter()
                .chain(&pattern.guide.games)
                .all(|g| g.prob[out[g.index] as usize] > 0.)
                && pattern
                    .joint
                    .selected
                    .iter()
                    .all(|&t| points[t] >= pattern.lower[t] && points[t] <= pattern.upper[t]);
            assert!(!hit || supported, "lost necessary joint support");
            if !supported {
                continue;
            }
            event += mass;
            if hit {
                let mut prefix = pattern.base.clone();
                for g in &pattern.joint.games {
                    let o = out[g.index] as usize;
                    prefix[g.home] += g.hg[o];
                    prefix[g.away] += g.ag[o];
                }
                for (step, g) in pattern.guide.games.iter().enumerate() {
                    let o = out[g.index] as usize;
                    let counts = pattern.counts(step, &prefix, p.cell).unwrap();
                    for candidate in 0..3 {
                        let mut after = prefix.clone();
                        after[g.home] += g.hg[candidate];
                        after[g.away] += g.ag[candidate];
                        assert_eq!(
                            pattern.next_counts(step, &prefix, p.cell, candidate, counts),
                            pattern.counts(step + 1, &after, p.cell),
                            "incremental rank cardinality changed support"
                        );
                    }
                    assert!(
                        pattern.allows(step, &prefix, p.cell, o),
                        "lost prefix rank support"
                    );
                    prefix[g.home] += g.hg[o];
                    prefix[g.away] += g.ag[o];
                }
            }
        }
        (event, rank)
    }
    #[test]
    fn complete_propagated_union_matches_exhaustive_mass_and_preserves_every_rank_hit() {
        for sort in ["pt,w,bias", "pt,bias"] {
            let m = league(sort);
            for team in 0..4 {
                for rank in 0..4 {
                    for limit in [0, 1, 3] {
                        let Some(p) =
                            PropagatedJoint::with_limits(&m, Cell { team, rank }, 0, limit)
                        else {
                            continue;
                        };
                        let (event, _) = exact(&m, &p);
                        assert!(
                            (p.mass - event).abs() < 1e-12,
                            "sort={sort} team={team} rank={rank} mass={} exact={event}",
                            p.mass
                        );
                    }
                }
            }
        }
    }
    #[test]
    fn propagated_joint_weights_match_exact_ranks_with_and_without_guidance() {
        for sort in ["pt,w,bias", "pt,bias"] {
            let m = league(sort);
            for rank in 0..4 {
                let p = PropagatedJoint::with_limits(&m, Cell { team: 0, rank }, 0, 1).unwrap();
                let (_, expected) = exact(&m, &p);
                for guided in [false, true] {
                    let r = p.sample(&m, 10000, 808, guided);
                    assert!(
                        (r.probability - expected).abs() < 6. * r.std_err + 1e-12,
                        "sort={sort} rank={rank} guided={guided} estimate={} exact={expected}",
                        r.probability
                    );
                }
            }
        }
    }
    #[test]
    fn reversed_guidance_retains_tiny_upper_tail_and_real_goal_tiebreakers() {
        let g = RankGame {
            index: 0,
            home: 0,
            away: 1,
            prob: [1. - 1e-20, 0., 1e-20],
            hg: [0, 1, 3],
            ag: [3, 1, 0],
        };
        let guide = Guide::new(vec![g], 2);
        assert_eq!(guide.factor(0, 0, 2, 0., 1.), 1e-20);
        let m = league("pt,w,gd,gf,bias");
        let p = PropagatedJoint::with_limits(&m, Cell { team: 0, rank: 1 }, 0, 1).unwrap();
        let r = p.sample(&m, 20000, 808, true);
        let mut rng = Rng::new(1123);
        let mut scores = ScoreContext::new(&m);
        let mut out = vec![0; m.fixtures.len()];
        let mut hits = 0;
        for _ in 0..20000 {
            for (i, g) in m.fixtures.iter().enumerate() {
                out[i] = choose(g.prob, 1., &mut rng) as u8;
            }
            hits += usize::from(scores.rank(0, &out, &mut rng, None) == 1);
        }
        let estimate = hits as f64 / 20000.;
        let se = (estimate * (1. - estimate) / 20000.).sqrt();
        assert!((r.probability - estimate).abs() < 6. * (r.std_err * r.std_err + se * se).sqrt());
    }
    #[test]
    fn exceeding_complete_pattern_budget_skips_instead_of_truncating() {
        let mut m = league("pt,w,bias");
        let games = m
            .fixtures
            .iter()
            .enumerate()
            .map(|(index, g)| RankGame {
                index,
                home: g.home,
                away: g.away,
                prob: g.prob,
                hg: [0, 1, 3],
                ag: [3, 1, 0],
            })
            .collect::<Vec<_>>();
        let base = m.base.iter().map(|c| c.points).collect::<Vec<_>>();
        let lower = base.iter().map(|p| p + 1).collect::<Vec<_>>();
        let upper = base.iter().map(|p| p + 9).collect::<Vec<_>>();
        assert!(NecessaryJoint::new(&games, &base, &lower, &upper, 3, 0).is_none());
        let (joint, _) = NecessaryJoint::new(&games, &base, &lower, &upper, 3, 10000).unwrap();
        assert!(joint.states > 0 && joint.states <= 10000);
        m.request.games.extend(m.request.games.clone());
        m = Model::new(m.request).unwrap();
        assert!(PropagatedJoint::with_limits(&m, Cell { team: 0, rank: 1 }, 0, 1).is_none());
        m.keys = vec![Key::Gd, Key::Pt];
        assert!(PropagatedJoint::new(&m, Cell { team: 0, rank: 1 }).is_none());
    }
}
